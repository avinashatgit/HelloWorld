/**
 */
package io.getgauge.spec;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see io.getgauge.spec.SpecPackage#getElement()
 * @model
 * @generated
 */
public interface Element extends EObject
{
} // Element
