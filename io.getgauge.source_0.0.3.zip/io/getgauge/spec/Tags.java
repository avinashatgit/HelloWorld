/**
 */
package io.getgauge.spec;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tags</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see io.getgauge.spec.SpecPackage#getTags()
 * @model
 * @generated
 */
public interface Tags extends Element
{
} // Tags
